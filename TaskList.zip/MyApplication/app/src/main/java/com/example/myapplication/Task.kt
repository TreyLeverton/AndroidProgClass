data class Task(
    val id: Int,
    var name: String,
    var isCompleted: Boolean
)
